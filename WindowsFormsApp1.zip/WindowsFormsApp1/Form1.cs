﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random rand = new Random();

            // Tạo màu ngẫu nhiên
            int red = rand.Next(0, 256);
            int green = rand.Next(0, 256);
            int blue = rand.Next(0, 256);
            int yellow = rand.Next(0, 256);
            int violet = rand.Next(0, 256);

            // Đặt màu ngẫu nhiên cho label1
            label1.ForeColor = Color.FromArgb(red, green, blue);
        }


            private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Đây là sự kiện di chuyển chuột ! ");

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Text = "Bài tập 2 – Chương 2";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DialogResult result =  MessageBox.Show("Bạn có muốn thoát chương trình không", "Xác nhận ", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
            if (result == DialogResult.No)
            {
                MessageBox.Show("Ban đã chọn ở lại");
            }

        }
    }
}
